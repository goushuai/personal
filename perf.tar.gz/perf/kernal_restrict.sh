echo 1 > /proc/sys/kernel/kptr_restrict

cd data
python -m SimpleHTTPServer 10030

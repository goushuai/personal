# input: 待采集的进程pid
target=server_perf_top
cd data

# 堆栈信息采样，采样频率频率：99 fps，抓取进程 $1，采样时间：120秒
perf record -g --call-graph dwarf -F 99 -p $1 sleep 60
mv perf.data ${target}.data

# 转换生成火焰图
perf script -i ${target}.data > ${target}.perf
/root/gs/perf/flamegraph/stackcollapse-perf.pl ${target}.perf > ${target}.folded
/root/gs/perf/flamegraph/flamegraph.pl ${target}.folded > ${target}.svg

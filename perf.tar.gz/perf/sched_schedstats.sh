echo 1 > /proc/sys/kernel/sched_schedstats
